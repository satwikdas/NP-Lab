// Q1C. Design a C program to implement Byte stuffing concept in data link layer.

// DO WE HAVE THIS !?
